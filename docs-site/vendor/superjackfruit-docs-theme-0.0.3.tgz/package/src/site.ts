// What every component knows about the site it is on: the product (from the plugin, through a
// virtual module), and the suite's product list. A component's own `product` prop wins, so a
// component can also be rendered outside a themed site (the tests do).
import theme from 'virtual:sjl-docs/theme';
import { ORDER, PRODUCTS } from '@superjackfruit/frontdoor/data';
import { STATUSES, statusOf } from './tokens.mjs';

export { STATUSES, statusOf };

/** The suite, in street order. */
export const SUITE = { order: ORDER, products: PRODUCTS };

/**
 * What a component is for: its prop, else the site's. A product gives its frontdoor record. A site
 * that is not a product (the plugin's `site` option, such as Treaty) gives the same fields, and is
 * never a house on the street: `product` is false, its colour is the accent it wears
 * (`--sjl-brand`), and its mark is the mark of whose look it wears (the lab's).
 */
export function productOf(prop?: string) {
  const site = theme?.site;
  if (site && (prop === undefined || prop === site.slug)) {
    return { ...site, color: 'var(--sjl-brand)', role: site.line, mark: site.wears, product: false as const };
  }
  const slug = prop ?? theme?.product;
  const p = SUITE.products[slug];
  if (!p) throw new Error(`docs-theme: unknown product "${slug}"`);
  return { ...p, slug, mark: slug, landing: p.url, product: true as const };
}

/** The site's own status word (the plugin's `status` option), or null. */
export const siteStatus = () => theme?.status ?? null;

/** Where a product's landing page is, as the reader says it: "superdispatch.dev". */
export const hostOf = (url) => new URL(url).hostname;

/**
 * Starlight's route data, or undefined where there is none: starlight-llms-txt renders page
 * content outside a Starlight route, and Starlight's getter throws there.
 */
export function routeOf(locals: unknown): any {
  try { return (locals as { starlightRoute?: unknown }).starlightRoute; } catch { return undefined; }
}

/**
 * Whether a page wears frontdoor's full suite footer: only the docs home and the 404. Every other
 * page ends with the quiet line instead.
 */
export function wearsSuiteFooter(route: any): boolean {
  if (!route) return false;
  // Starlight's id for the docs home is '' (index.mdx); the theme's 404 page is '404'.
  return route.id === '' || route.id === '404';
}
