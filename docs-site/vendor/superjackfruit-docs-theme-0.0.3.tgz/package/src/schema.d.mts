// Types for schema.mjs, so a site's content.config.ts type-checks (`astro check`).
import type { docsSchema } from '@astrojs/starlight/schema';
import type { ZodType } from 'astro/zod';

/** "lit & steady", "lights on", "half-lit" or "wet paint" (or their keys); anything else fails the build. */
export declare const statusField: ZodType;
/** Starlight's docs schema plus `status:`. */
export declare function sjlDocsSchema(): ReturnType<typeof docsSchema>;
