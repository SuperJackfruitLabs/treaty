# Changelog

## 0.0.3

- **A site that is not a product.** `sjlDocs({ site: { slug, name, url, docs?, repo, line, wears: 'lab' } })` dresses a docs site that is not a product, such as Treaty, the suite's contracts. The operator decided on 2026-11-14 that Treaty wears the lab's look, not a product colour. The site wears vibekit's `SITE_ACCENTS.lab` (graphite, neutral); the lab's amber appears only in the lab's mark. It shows its own name beside the lab's mark. The street, the switchers and the suite footer show the suite with no product marked as here. Its way out is its landing page, or the lab's home when the docs are the whole site. Footers, the 404, Copy Markdown and Open as Markdown, llms.txt and the edit link all work. BentoHome, CopyPrompt and CaptainJack take the site; Ask sends its slug, which the suite worker knows for `treaty`. See the README.
- On a non-product site the lab's suite footer takes the site's accent for its own colour (the focus ring, Captain Jack's panel), so the lab's amber stays in the marks.
- **Fixed:** the Work with an agent prompt no longer runs past its tile. A long address (an llms-full.txt URL) widened the tile's grid column by about 20px at desktop widths, on every site. An e2e test checks 1440, 1100 and 390px.
- `product:` works exactly as before for every product.
- Needs vibekit 0.0.17 (for `SITE_ACCENTS`); the workspace vendors it.
- **Types for the schema.** `src/schema.d.mts` types `sjlDocsSchema` and `statusField`, so a site's `content.config.ts` passes `astro check` (it failed with ts(7016) before).
- **Tests.** The fixture is also built as Treaty (`fixture/astro.site.config.mjs`, into `dist-site/`), and `test/site.test.ts` checks it. Plugin tests cover the option and its refusals.

## 0.0.2

- **A quieter foot.** Only the docs home and the 404 wear frontdoor's full suite footer. Every other page keeps Starlight's previous and next, edit link and last-updated date, then one line: "Part of Super Jackfruit Labs" and a Products switcher that opens the suite's list.
- **FlowSteps is a tablist.** The range slider is gone. The steps are numbered tabs with one tab stop; Left and Right follow the text direction, Home and End jump, and the arrows stop at either end (`loop` wraps). Back and Next are 44px targets that keep focus at either end. Transitions run only under `prefers-reduced-motion: no-preference`; the stepper works the same with reduced motion. The pattern follows Vercel's UI SDK tabs, focus and motion docs, and lives in `src/client/steps.ts`.
- **`DecisionReplay`**, a new component: a recorded SuperDispatch placement decision, stepped through with the same tabs, from a JSON file in the site. Nothing to install.
- **`CopyPrompt`**, a new component: a prompt for a coding agent naming the product's `llms.txt` and `llms-full.txt`. BentoHome shows it in a new Work with an agent tile (`agent`, or `agent={false}`).
- **Every page as Markdown** at `<page>.md`, and an Open as Markdown link beside Copy Markdown. Both give the same text.
- **BentoHome**: the Quick start takes a `quickstart` slot, for a quick start that needs nothing installed, and spans the full width. The Quick start's Copy and Copy Markdown announce "Copied". When the clipboard is blocked, the Quick start's Copy selects the command.
- **Controls.** Captain Jack's Ask button stays focusable while he reads. A theme button with the `hidden` attribute is now hidden; before, its `display` overrode it. On touch screens theme buttons are at least 44px tall.
- **Tests.** `npm run e2e` drives the fixture in Chrome. The fixture build points `cookie` at Astro's own copy, so it builds in the workspace again.

## 0.0.1

The first release, with frontdoor 0.0.15. See frontdoor's CHANGELOG.
