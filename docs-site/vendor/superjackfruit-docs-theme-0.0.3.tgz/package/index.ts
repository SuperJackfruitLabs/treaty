// @superjackfruit/docs-theme: the suite's docs design as one Starlight plugin. A site's whole
// design config is
//
//   starlight({ title, plugins: [sjlDocs({ product: 'superdispatch' })], sidebar })
//
// and the plugin brings the rest. A site that is not a product (Treaty, the suite's contracts) names
// itself instead, and wears the lab's look:
//
//   sjlDocs({ site: { slug: 'treaty', name: 'Treaty', url, repo, line, wears: 'lab' } })
//
// The theme brings vibekit's colours for the product (or the site's accent), the shared fonts (self-hosted),
// the site title, the street as the suite map, the status badges, Copy Markdown and Open as
// Markdown (every page at <page>.md), the footers, the 404, llms.txt, the edit link and
// last-updated dates, and a check that the sidebar uses the suite's five groups. Components for
// pages (BentoHome, CaptainJack, CopyPrompt, FlowSteps, DecisionReplay, the callouts) are
// imported from '@superjackfruit/docs-theme/components/<Name>.astro'.
//
// TypeScript on purpose, like starlight-llms-txt: Node will not run TypeScript from node_modules,
// so Astro loads a config that imports this file through Vite, which compiles it.
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import starlightLlmsTxt from 'starlight-llms-txt';
import { PRODUCT_ACCENTS, SITE_ACCENTS } from '@superjackfruit/vibekit/appearance';
import { ORDER, PRODUCTS, SITES, type Slug } from '@superjackfruit/frontdoor/data';
import type { StarlightPlugin } from '@astrojs/starlight/types';
import { sidebarWarnings } from './src/sidebar.mjs';
import { statusOf, themeCss } from './src/tokens.mjs';

const require = createRequire(import.meta.url);
const C = (name: string) => `@superjackfruit/docs-theme/components/${name}.astro`;

/** The theme's CSS for one vibekit accent, light and dark. */
export function accentCss(accent: string): string {
  const read = (spec: string) => readFileSync(require.resolve(spec), 'utf8');
  return themeCss(read('@superjackfruit/vibekit/accents.css'), read('@superjackfruit/vibekit/tokens.css'), accent);
}

/** The theme's CSS for one product: vibekit's tokens for it, light and dark. */
export function productCss(product: string): string {
  const accent = (PRODUCT_ACCENTS as Record<string, string>)[product];
  if (!accent) throw new Error(`docs-theme: vibekit names no accent for "${product}"`);
  return accentCss(accent);
}

/** Whose look a non-product site wears. Only the lab's, for now. */
export type Wears = 'lab';

/**
 * A docs site that is not a product: it is never a house on the street, and it wears the look of
 * `wears` (vibekit's SITE_ACCENTS names the accent; the lab's is graphite) and that site's mark.
 */
export interface SjlSite {
  /** A short id ('treaty'): lowercase letters, digits and dashes, and no product's slug. */
  slug: string;
  /** The name in the header and the page titles ('Treaty'). */
  name: string;
  /** The site's address. When it has a landing page of its own, `docs` is the docs' address. */
  url: string;
  /** The docs' address, when it is not `url`. */
  docs?: string;
  /** The repository, for the edit link and the Source link (null when there is none). */
  repo: string | null;
  /** One line saying what it is, for llms.txt and the street's title. */
  line: string;
  wears: Wears;
}

/** The site record the components read (virtual:sjl-docs/theme): what they need of a product, for a site. */
export function siteRecord(site: SjlSite) {
  const where = `docs-theme: site "${site?.slug}"`;
  if (!site || typeof site.slug !== 'string' || !/^[a-z][a-z0-9-]*$/.test(site.slug)) throw new Error(`${where}: slug must be lowercase letters, digits and dashes`);
  if (site.slug in SITES) throw new Error(`${where}: "${site.slug}" is a product or the lab; use product: '${site.slug}' instead`);
  for (const k of ['name', 'line'] as const) if (typeof site[k] !== 'string' || !site[k].trim()) throw new Error(`${where}: ${k} is required`);
  for (const k of ['url', 'docs', 'repo'] as const) {
    const v = site[k];
    if (v == null) { if (k === 'url') throw new Error(`${where}: url is required`); continue; }
    if (typeof v !== 'string' || !/^https:\/\/[^/\s]+/.test(v)) throw new Error(`${where}: ${k} must be an https:// address`);
  }
  const lab = SITES[site.wears as 'lab'];
  const accent = (SITE_ACCENTS as Record<string, string>)[site.wears];
  if (site.wears !== 'lab' || !lab || !accent) throw new Error(`${where}: wears must be 'lab'`);
  const url = site.url.replace(/\/$/, '');
  const docs = (site.docs ?? site.url).replace(/\/$/, '');
  return {
    slug: site.slug, name: site.name.trim(), line: site.line.trim(), url, docs, repo: site.repo ?? null,
    wears: site.wears, accent,
    // The way out of the docs: the site's own landing page, or, when the docs are the whole site, the lab's.
    landing: docs === url ? lab.url : url,
  };
}

export interface SjlDocsOptions {
  /** The product's slug, as in frontdoor's product list ('superdispatch'). Give this or `site`. */
  product?: Slug;
  /** A docs site that is not a product, such as Treaty. Give this or `product`. */
  site?: SjlSite;
  /** The site's status word, beside its title: "wet paint", "half-lit", "lights on" or "lit & steady". */
  status?: string;
  /** The docs site's folder in the repo, for the edit link (default 'docs-site/'). */
  docsDir?: string;
  /** Options for starlight-llms-txt (on by default), or false to leave it off. */
  llms?: false | { description?: string; details?: string; optionalLinks?: { label: string; url: string; description?: string }[] };
}

export default function sjlDocs(options: SjlDocsOptions): StarlightPlugin {
  const { product, docsDir = 'docs-site/' } = options ?? ({} as SjlDocsOptions);
  if (product !== undefined && options.site !== undefined) throw new Error('docs-theme: give product or site, not both');
  const site = options?.site === undefined ? null : siteRecord(options.site);
  const prod = site ? null : (PRODUCTS as Record<string, (typeof PRODUCTS)[Slug]>)[product as string];
  if (!site && !prod) throw new Error(`docs-theme: unknown product "${product}"; one of ${ORDER.join(', ')}, or a site: { … }`);
  const me = site ?? { slug: product as string, name: prod!.name, line: prod!.line, url: prod!.url, repo: prod!.repo };
  const status = options.status === undefined ? undefined : statusOf(options.status);
  if (options.status !== undefined && !status) throw new Error(`docs-theme: status "${options.status}" is not one of wet paint, half-lit, lights on, lit & steady`);
  const llms = options.llms === false ? null : starlightLlmsTxt({
    projectName: me.name,
    description: options.llms?.description ?? `${me.name}: ${me.line}`,
    ...(options.llms?.details ? { details: options.llms.details } : {}),
    optionalLinks: options.llms?.optionalLinks ?? [
      ...(site ? (site.landing === site.url ? [{ label: me.name, url: me.url, description: 'The site.' }] : []) : [{ label: me.name, url: me.url, description: 'The product site.' }]),
      ...(me.repo ? [{ label: 'Source', url: me.repo, description: `The ${me.name} repository.` }] : []),
    ],
  });

  return {
    name: '@superjackfruit/docs-theme',
    hooks: {
      async 'config:setup'(ctx) {
        const { config, updateConfig, addIntegration, logger } = ctx;
        for (const w of sidebarWarnings(config.sidebar)) logger.warn(w);

        const theme = { product: site ? null : me.slug, site, name: me.name, landing: site ? site.landing : me.url, status: status ?? null };
        updateConfig({
          components: {
            SiteTitle: C('SiteTitle'),
            Header: C('Header'),
            PageTitle: C('PageTitle'),
            Footer: C('Footer'),
            ...config.components,
          },
          customCss: ['@superjackfruit/docs-theme/styles/fonts.css', '@superjackfruit/docs-theme/styles/theme.css', ...(config.customCss ?? [])],
          head: [
            { tag: 'style', attrs: { 'data-sjl-docs': me.slug }, content: site ? accentCss(site.accent) : productCss(me.slug) },
            ...(config.head ?? []),
          ],
          editLink: config.editLink?.baseUrl ? config.editLink : me.repo ? { baseUrl: `${me.repo}/edit/main/${docsDir}` } : config.editLink,
          lastUpdated: config.lastUpdated ?? true,
          disable404Route: true,
        });

        addIntegration({
          name: '@superjackfruit/docs-theme/routes',
          hooks: {
            'astro:config:setup'({ injectRoute, updateConfig: updateAstro }) {
              injectRoute({ pattern: '404', entrypoint: '@superjackfruit/docs-theme/pages/404.astro', prerender: true });
              // Every page as Markdown at `<page>.md` (Open as Markdown links it).
              injectRoute({ pattern: '/[...slug].md', entrypoint: '@superjackfruit/docs-theme/pages/markdown.ts', prerender: true });
              // The theme's settings, for its components (virtual module: no file in the site).
              updateAstro({ vite: { plugins: [virtualTheme(theme)] } });
            },
          },
        });

        if (llms) {
          const hooks = llms.hooks as Record<string, ((c: typeof ctx) => unknown) | undefined>;
          const setup = hooks['config:setup'] ?? hooks.setup;
          await setup?.(ctx);
        }
      },
    },
  };
}

function virtualTheme(theme: object) {
  const id = 'virtual:sjl-docs/theme';
  return {
    name: 'sjl-docs-theme',
    resolveId: (x: string) => (x === id ? `\0${id}` : undefined),
    load: (x: string) => (x === `\0${id}` ? `export default ${JSON.stringify(theme)};` : undefined),
  };
}
